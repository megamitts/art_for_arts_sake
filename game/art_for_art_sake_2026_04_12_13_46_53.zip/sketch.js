/*

In the art world, everyone is a critic! Make art and try to please the Emoji critic, who certainly isn't random. Honest!

Drag and drop the rectangles to make a glorious piece of...art. More rectangles will appear as you create. This 
may enhance or ruin your piece.

Press S to save it and flog it as a worthless NFT to some fool!

Made quickly for Sticky #WCCChallenge.

Sticky? Well, you can stick the rects to different parts of the canvas. Yes, yes that's pushing it 😛 

music: Tsorthan Grove https://opengameart.org/users/tsorthan-grove
*/

let score = 0;

let rectangles = [];
//let emojiCritics = ["😀","🥰","🤬","🙁","🥴","😤", "🧐", "🫣", "😁", "🤮", "🥹", "🤩", "🤔", "🙄","🥱", "😚"];

let emojiCritics = [
	{ char: '🧐', score: 1},
  { char: '😤', score: 0},
  { char: '🤬', score: 0},
  { char: '🤔', score: 2},
  { char: '😵‍💫', score: 0},
  { char: '🤮', score: 0},
  { char: '🤑', score: 20},
  { char: '🥳', score: 15},
	{char: '🥰', score: 10},
	{char: '😁', score: 5},
	{char: '🥱', score: 0}
		
	
	
];

let selectedRect = null;
let offsetX = 0;
let offsetY = 0;
let t = 0;
let critic = ["🧐"];
let music;
//let loaded = false;

async function setup() {
  createCanvas(600, 400);
  music = await loadSound('music.mp3');
  //loaded = true;
  noStroke();
  // Create some rectangles to start
  rectangles.push(new StickyRect(50, 50, 100, 60));
  rectangles.push(new StickyRect(200, 150, 120, 80));
  rectangles.push(new StickyRect(400, 100, 80, 100));
  playMusic();
  music.onended(playMusic);
}

function draw() {
  
  
  
  background(240);

    
  // Draw them there rectangles
  for (let rectObj of rectangles) {
    rectObj.display();
  }
  
  textSize(80);
  text(critic,500,380);
	stroke('green');
	fill('green');
  text(score, 0,380);
	noStroke();
  t+=0.02;
  
}

function mousePressed() {
  // Check if mouse is inside any rectangle 
  for (let i = rectangles.length - 1; i >= 0; i--) {
    if (rectangles[i].contains(mouseX, mouseY)) {
      selectedRect = rectangles[i];
      // Bring selected rectangle to front like a boss!
      rectangles.splice(i, 1);
      rectangles.push(selectedRect);

      // Store offset so rectangle doesn't jump around like a 90s raver on speed!
      offsetX = mouseX - selectedRect.x;
      offsetY = mouseY - selectedRect.y;
      break; //in' 2: Electric Boogaloo!
    }
  }
}

function mouseDragged() { //life as a mouse is such a drag. 
  if (selectedRect) {
    selectedRect.x = mouseX - offsetX 
    selectedRect.y = mouseY - offsetY 
  }
}

function mouseReleased() { // go little mouse. Explore the world. 
  
  if (selectedRect) {  //what the hell is going on here? The lad must be trippin!
    rectangles.push(new StickyRect(random(50)*cos(t), random(50)*sin(t), 100*cos(t), 60*sin(t)));
    rectangles.push(new StickyRect(200*tan(t), random(150)*sin(t/2), 120*tan(t), 80*sin(t/2)));
    rectangles.push(new StickyRect(random(400)*cos(t/3), 100*tan(t**2), 80*cos(t/3), 100*tan(t**2)));

    let i = Math.floor(Math.random() * emojiCritics.length);
    let randomCritic = emojiCritics[i]; // okay, I lied. The critic is random. If I expand it into a full game I'll add a proper points system.
	  critic = randomCritic.char;
	  score = score + randomCritic.score;
  }

  selectedRect = null; 
  
  
  
}

// Rectangle class with amusing name (if you're 14!)
class StickyRect {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.col = color(random(255), random(255), random(255));
  }

  display() {
    
    fill(this.col);
    rect(this.x, this.y, this.w, this.h);
  }

  contains(px, py) {
    return px >= this.x && px <= this.x + this.w &&
           py >= this.y && py <= this.y + this.h;
  }
}

function keyPressed() { 
  if (key === 's' || key === 'S') {
    let savedCritic = critic; 
	  let savedScore = score;
	  score = '';
    critic = '';               
    redraw();                  
    saveCanvas('my-art', 'png');
    critic = savedCritic; 
	  score = savedScore;
  }
	if (key ==='c' || key === 'C'){
		critic = '🧐';
		score = 0;
		background(240);
		rectangles = [];
		rectangles.push(new StickyRect(50, 50, 100, 60));
  rectangles.push(new StickyRect(200, 150, 120, 80));
  rectangles.push(new StickyRect(400, 100, 80, 100));
		
	}
}

function playMusic(){
  music.play();
}

/* You've reached the end, well not much more to say really. Thanks for playing.

Oh go on then, you can have a bit more. Here's a poem I wrote a long time ago:

Me and Elvis Once Went On a Foodfest
by megamitts

Me and Elvis once went for a food fest,
One late August night,
The sign flashed "All You Can Eat!",
So we stopped in for a bite.

Elvis gobbled down thirty cheeseburgers,
Faster than I'd ever seen,
He swilled them down with ten milkshakes,
And a bucket of chocolate ice cream.

Then he ordered a mega huge curry,
And twelve massive naan bread too,
I pleaded "Elvis, please stop eating!",
It was all that I could do.

But the singer sank down twenty prime ribs,
And a nice fat juicy steak,
I had to turn my head away,
It was more than I could take.

Still Elvis kept on eating,
His appetite yet did burn,
And the size of them cakes he shoved down his gob,
Sure made my stomach churn.

He wolfed down ten packets of biscuits,
And a huge lump of blue stilton cheese,
By the end of that dreadful evening,
His stomach sat plump on his knees.

At last he supped a cup of coffee,
Sang "Cheerio!" and went on his way,
They found him dead on the toilet,
The very next day.

But what the police didn't tell us,
What the papers didn't say,
Not only did Elvis snuff it,
He blew the toilet away!

See ya next time! Y'all come back now, ya hear!

- mitts

*/